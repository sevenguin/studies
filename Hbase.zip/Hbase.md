#Hbase
Hbase是一个Hadoop数据库，如果你需要随机、试试读写大数据，HBase可以帮你做到。HBase项目的目标是处理非常大的表——数十亿行和百万列的的表

###Architecture
####Overview
Hbase缺少RDBMS中的第二索引、触发器和高级查询语句
* HBase表通过regions来在集群中分布式存放，随着你的数据增长，region会自动的split和重新分布
* RegionServer自动灾备切换
* HBase支持HDFS作为其分布式存储文件系统
* HBase支持大量MR处理，可以将HBase作为源和目的
* HBase支持使用JavaAPI来处理数据
* HBase支持Thrift和REST API，所以可以支持非Java语言来连接使用
* HBase支持块缓存以及布隆过滤器（Bloom Filter）来使得大量数据查询最优

#####HBase的使用情况
1. 大量数据
2. 不会用到RDBMS的一些额外特性（其实就是HBase无法满足的）
3. 确定有足够的硬件（HDFS少于5个Datanode则不能很好的工作）

#####HBase和HDFS的差别
HDFS是分布式的文件系统，适合存放大的文件，作为一个文件系统，他不提供单独的记录查询。另一方面，HBase是构建在HDFS上，为大表提供快速记录查询。可以这么理解，HBase实质上是把数据组成索引号的存储文件，存储在HDFS上。（HBase+Hive可以通过Impala给替换掉？）
catalog table（目录表）hbase:meta作为一个HBase表存在，HBase shell的list命令会过滤掉这个元数据表。

> $-ROOT-:$ 已经在HBase0.96.0中移除掉，所以这里简单说明一下，-ROOT-表记录.META表的位置信息，-ROOT-表结构如下：
> * $Key$ .META region key
> * $Values$ info:regioninfo; info:server; info:serverstartcodei

####hbase:meta
hbase:meta（之前叫做.META.）保存了一个regions的列表，而hbase:meta的位置信息之前是在-ROOT-中记录的，但现在是存在zookeeper中。   
hbase:meta表结构如下：
* $Key$ region key的格式（[table],[region start key],[region id]）
* $Values$ 
	* $info:regioninfo$   region的实例信息，格式为：HBaseInfo类型的序列化
	* $info:server$ 这个region所在的RegionServer的地址，格式为：server:port
	* $info:serverstartcode$ 这个region所在RegionServer开始处理时间

当一个表被拆分时，会增加一行数据包含两列——info:splitA和info:splitB，这两列作为两个子region，这两列的值就是info:regioninfo，等到拆分结束，这行数据就会被删掉。
> HRegionInfo
> key值为空表示一个表的开始和结尾，如果一个region有一个空的key，则这个region是这个表的第一个region，如果这个region有一个空的开始、一个空结尾key，则说明这个表就只有这一个region

####Client
一个HBase客户端通过查看hbase:meta的详细信息获得所需要数据的RegionServers，然后直接从RegionServer处获得数据，而不去和master沟通（和hdfs读数据类似），client会缓存这这些region和regionserver的对应信息以提供子查询，如果master进行负载均衡或一个RegionServer死掉，Hbase客户端需要重新请求Catalog tables，来获得用户region的新位置。

####Master
HMaster是Master Server的实现，HMaster的任务是检测集群中所有的RegionServer和所有metadata接口的变动。在分布式集群中，HMaster一般运行在NameNode上。
HMaster也可以部署多个，通过Zookeeper进行选举产生主的Master
由于HMaster不存储Catalog table，client读取数据也是直接从RegionServer读取，所以HMaster死掉之后系统还是可以稳定运行的，但是Master控制了RegionServer的灾备切换和region split，所以这个稳定也是一小段时间。
$Master架构详见$：[Master的架构](http://blog.zahoor.in/2012/08/hbase-hmaster-architecture/)
Master相关组件：
![Alt text](./1460963233764.png)


####RegionServer
HRegionServer用来管理regions，在分布式系统中，RegionServer运行在DataNode上.
Region先写入内存（memstore），一旦memstore写满，它的内容被写入磁盘（增加一个文件），这个动作叫做memstore flush。随着sotre files累计，RegionServer会把它们合并，等到这些操作做完，region包含的数据量就变了，RegionServer根据Split policy，决定是否拆分。拆分前后RegionServer都需要和Master沟通，更新meta。拆分后，实际的存储文件不拆分，而是创建一些连接文件指向原来的文件（这样可以避免拷贝复制数据）

####WAL（Write Ahead Log）
正如上面所说，数据线存入memsotre，然后等到memstore写满，然后flush到StoreFiles，但是在flush之前，RegionServer Clash掉，数据就有丢失的风险，这就是WAL存在的意义，WAL保证了修改的数据可以重新被执行。如果WAL写操作失败，那此次操作就会失败。
通常，一个RegionServer只有一个WAL实例，RegionServer在操作memstore之前，先写入log。
WAL在Hdfs中有个目录/hbase/WALs(0.94之前，存在/hbase/.log中，当时叫做HLog)，每一个region在这个目录下都有一个子目录


